#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "random.h"
#include "game.h"
#include "map.h"
#include "linked_list.h"
#include "terminal.h"
/*Read map file => Int game => User input => Manage game loop*/
int main(int argc, char *argv[]) {
    int mapRow, mapCol, playerRow, playerCol, goalRow, goalCol, boxRow, boxCol;
    int i, row, col;
    char entity;
    int wallsCount = 0;
    char key;
    int** map = NULL;
    LinkedList* list;
    Values* val, *initVal;
    int* result;
    int returnValue = 0;  /*store return val*/

    if (argc != 2) {
        printf("Usage: %s <map_filename>\n", argv[0]);
        returnValue = 1;  /*Set return value to indicate an error*/
    } else {
        int* wall = NULL;

        FILE *fp;
        char line[100], *token;

        fp = fopen(argv[1], "r");
        if (fp == NULL) {
            printf("Error opening file.");
            returnValue = 1; /*Exception handling sort*/
        } else {
            fgets(line, 100, fp);
            token = strtok(line, " ");
            mapRow = atoi(token) + 2;
            token = strtok(NULL, " ");
            mapCol = atoi(token) + 2;
            i = 0;
            wall = (int*) malloc(sizeof(int) * mapRow * mapCol);
            while (fgets(line, 100, fp) != NULL) {
                token = strtok(line, " ");
                row = atoi(token);
                token = strtok(NULL, " ");
                col = atoi(token);
                token = strtok(NULL, " ");
                entity = token[0];
                if (entity == 'P') {
                    playerRow = row + 1;
                    playerCol = col + 1;
                } else if (entity == 'G') {
                    goalRow = row + 1;
                    goalCol = col + 1;
                } else if (entity == 'B') {
                    boxRow = row + 1;
                    boxCol = col + 1;
                } else if (entity == 'O') {
                    wall[i] = row + 1;
                    wall[i + 1] = col + 1;
                    i += 2;
                }
            }

            fclose(fp);
            wallsCount = i - 1;
            map = (int**) malloc(sizeof(int*) * mapRow);
            for (i = 0; i < mapRow; i++) {
                map[i] = (int*) malloc(sizeof(int) * mapCol);
            }
            generateMap(map, mapRow, mapCol, wall, wallsCount);
            free(wall);
            updatePositions(map, playerRow, playerCol, 2);
            updatePositions(map, boxRow, boxCol, 3);
            disableBuffer();
            list = createLinkedList();
            initVal = (Values*) malloc(sizeof(Values));
            initVal->playerRow = playerRow;
            initVal->playerCol = playerCol;
            initVal->boxRow = boxRow;
            initVal->boxCol = boxCol;
            initVal->isBoxMoved = 0;
            insertNode(list, initVal);
            while (!isWon(boxRow, boxCol, goalRow, goalCol)) {
                updatePositions(map, goalRow, goalCol, 4);
                printMap(map, list, mapRow, mapCol, 0);
                if (goalRow == playerRow && goalCol == playerCol)
                    printMap(map, list, mapRow, mapCol, 3);
                printf("Move the box to the goal to win the game\n");
                printf("Press w to move up\n");
                printf("Press a to move left\n");
                printf("Press s to move down\n");
                printf("Press d to move right\n");
                printf("Press u to undo\n");
                key = direction();
                if (key == 'u') {
                    undo(list, map, &playerRow, &playerCol, &boxRow, &boxCol);
                } else {
                    val = (Values*) malloc(sizeof(Values));
                    result = movePlayer(map, mapRow, mapCol, playerRow, playerCol, boxRow, boxCol, key);
                    if (result[0] > 0 && result[1] > 0) {
                        val->isBoxMoved = 0;
                        if (result[2] > 0 && result[3] > 0) {
                            val->boxRow = boxRow;
                            val->boxCol = boxCol;
                            val->isBoxMoved = 1;
                            boxRow = result[2];
                            boxCol = result[3];
                        }
                        val->playerRow = playerRow;
                        val->playerCol = playerCol;
                        playerRow = result[0];
                        playerCol = result[1];
                        insertNode(list, val);
                    } else {
                        free(val);
                    }
                    free(result);
                }
            }
            updatePositions(map, goalRow, goalCol, 4);
            printMap(map, list, mapRow, mapCol, 1);
            printf("Congratulations! You Won\n");

            for (i = mapRow - 1; i >= 0; i--) {
                free(map[i]);
            }
            freeLinkedList(list);
            free(map);
        }
    }
    return returnValue;
}
