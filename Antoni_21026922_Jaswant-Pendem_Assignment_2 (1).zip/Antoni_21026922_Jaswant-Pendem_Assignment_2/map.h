#include "color.h"
#include "linked_list.h"
#include <stdio.h>
#include <stdlib.h>

#define BORDER "*"
#define EMPTY " "
#define PLAYER "P"
#define BOX "B"
#define GOAL "G"
#define WALL "O"

#ifndef MAP_H
#define MAP_H

/*Fun 1 to create map*/
void generateMap(int** map, int rows, int cols, int* wall, int size);
/*Fun 2 to update the positions*/
void updatePositions(int** map, int x, int y, int value);
/*Fun 3 to print map*/
void printMap(int ** map, LinkedList* list, int rows, int cols, int won);


#endif

