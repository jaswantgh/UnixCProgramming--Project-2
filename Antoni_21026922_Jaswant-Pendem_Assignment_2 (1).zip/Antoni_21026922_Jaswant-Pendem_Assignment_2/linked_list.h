#ifndef LINKED_LIST_H
#define LINKED_LIST_H

typedef struct LinkedListNode
{
	void * data;
	struct LinkedListNode * next;
}LLnode;

typedef struct
{
	LLnode * head;
	int size;
}LinkedList;

typedef struct
{
	int playerRow;
	int playerCol;
	int boxRow;
	int boxCol;
	int isBoxMoved;
}Values;

typedef int(*FP) (void *);
int isLastState(void*D); /*determine last node in LL*/

LinkedList* createLinkedList();  /*Create new LL*/
void insertNode(LinkedList * list, void * data ); /*new node at end of LL*/
void freeLinkedList(LinkedList* list); /*Free mem allocation*/
LLnode* removeNode(LinkedList* list, FP func); /*Rmv node from LL on fp for target node*/

#endif
