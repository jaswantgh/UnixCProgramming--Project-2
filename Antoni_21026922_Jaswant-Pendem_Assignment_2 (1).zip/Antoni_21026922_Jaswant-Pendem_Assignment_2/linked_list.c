#include <stdlib.h>
#include "linked_list.h"
/*Initialize new LL */
LinkedList* createLinkedList() {
    LinkedList* list = (LinkedList*)malloc(sizeof(LinkedList));
    list->head = NULL;
    list->size = 0;
    return list; /*Return ptr to create LL*/
}
/*Insert Node end of LL*/
void insertNode(LinkedList* list, void* data) {
    LLnode* newNode = (LLnode*)malloc(sizeof(LLnode));
    newNode->data = data;
    newNode->next = NULL;
    if (list->head == NULL) {
        list->head = newNode;
    } else {
        LLnode* currentNode = list->head;
        while (currentNode->next != NULL) {
            currentNode = currentNode->next;
        }
        currentNode->next = newNode;
    }
    list->size++;
}
/*Target node determined and pointer return to remove node*/
LLnode* removeNode(LinkedList* list, FP func) {
    LLnode* currentNode, *prevNode, *targetNode = NULL;
    currentNode = list->head;
    prevNode = NULL;
    for (; currentNode != NULL; currentNode = currentNode->next) {
        if (func(currentNode)) {
            if (prevNode == NULL) {
                list->head = currentNode->next;
            } else {
                prevNode->next = currentNode->next;
            }
            list->size--;
            targetNode = currentNode;
        }
        if (targetNode == NULL) {
            prevNode = currentNode;
        }
    }
    return targetNode;
}

/*Free mem allocated + helps with val.out for memory check stuff*/
void freeLinkedList(LinkedList* list) {
    LLnode* currentNode;
    for (currentNode = list->head; currentNode != NULL;) {
        LLnode* tempNode = currentNode;
        currentNode = currentNode->next;
        free(tempNode->data);
        free(tempNode);
    }
    free(list);
}

/*Insert at head of LL*/

void insertAtHead(LinkedList * list, void * data) {
    LLnode * newNode = malloc(sizeof(LLnode));
    if (newNode != NULL) {
        newNode->data = (Values*)data;
        newNode->next = list->head;
        list->head = newNode;
        list->size++;
    }
}


int isLastState(void* D) {
    LLnode* curNode = (LLnode*)D;
    int result = (curNode->next == NULL) ? 1 : 0; /*1 if last node, 0 otherwise*/
    return result;
}


/*Free mem allocated for Vlaues by data*/
void freeValues(void* data) {
    Values* value = (Values*)data;
    if (value != NULL) {
        free(value);
    }
}
