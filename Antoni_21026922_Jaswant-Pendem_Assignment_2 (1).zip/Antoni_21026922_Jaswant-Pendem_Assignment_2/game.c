#include <stdlib.h>
#include <stdio.h>
#include "game.h"
#include "map.h"
#include "linked_list.h"

/*Function to enable character input from keyboard from user to be read*/
char direction(){
    char ch;
    int valid;
    do {
        scanf(" %c", &ch);
        valid = (ch == 'w' || ch == 'a' || ch == 's' || ch == 'd' || ch == 'u');
        if(!valid){
            printf("Invalid Key. Enter w,a,s or d to move or u to undo\n");
        }
    } while (!valid);
    return ch;
}
/*Checks multi-directional for possible movmenets*/
int* checkDirections(int** map, int rows, int cols, int itemRow, int itemCol, char dir) {
    int* arr = (int*) malloc(3 * sizeof(int));
    int i;

    if (arr != NULL) {
        for (i = 0; i < 3; ++i) {
            arr[i] = -1;
        }
        if (itemRow + 1 < rows && dir == 's') {
            arr[0] = itemRow + 1;
            arr[1] = itemCol;
            arr[2] =  map[itemRow + 1][itemCol];
        }
        else if (itemRow - 1 >= 0 && dir == 'w') {
            arr[0] = itemRow - 1;
            arr[1] = itemCol;
            arr[2] = map[itemRow - 1][itemCol];
        }
        else if (itemCol + 1 < cols && dir == 'd') {
            arr[0] = itemRow;
            arr[1] = itemCol + 1;
            arr[2] = map[itemRow][itemCol + 1];
        }
        else if (itemCol - 1 >= 0 && dir == 'a') {
            arr[0] = itemRow;
            arr[1] = itemCol - 1;
            arr[2] = map[itemRow][itemCol - 1];
        }
    } else {
        fprintf(stderr, "Error: Memory allocation failed in checkDirections in game.c.\n");
    }
    return arr; /*Returned arrray to allow next, row, col and val at that pos of map*/
}




void moveBox(int** map, int boxRow, int boxCol, int row, int col, int pull) {
    if (pull) {
    #ifdef PULL_ENABLED
        updatePositions(map, boxRow, boxCol, 1); /*Positions are updated*/
        updatePositions(map, row, col, 3);
    #endif
    } else {
        updatePositions(map, row, col, 3);
    }
}

/*Returns opp dir key for given dir key*/
char reversed(char key) {
    char reversedKey = 's'; 
    if (key == 'a') {
        reversedKey = 'd';
    } else if (key == 's') {
        reversedKey = 'w';
    } else if (key == 'd') {
        reversedKey = 'a';
    } 
    return reversedKey;
}

/*Move player on map and pulls push box*/
int* movePlayer(int** map, int rows, int cols, int playerRow, int playerCol, int boxRow, int boxCol, char dir) {
    char back;
    int *item2, *item;
    int* array = (int*) malloc(4 * sizeof(int));
    int i;

    int* result = NULL;

    for (i = 0; i < 4; ++i) {
        array[i] = -1;
    }

    item = checkDirections(map, rows, cols, playerRow, playerCol, dir);
    if (!item) {
        free(array);
    }
    else if (item[2] == 0 || item[2] == 5) {       /* Border or Wall */
        result = array;
        free(item);
    }
    else if (item[2] == 1) {    /* Empty */
        updatePositions(map, item[0], item[1], 2);
        updatePositions(map, playerRow, playerCol, 1);
        array[0] = item[0];
        array[1] = item[1];

        back = reversed(dir);
        item2 = checkDirections(map, rows, cols, playerRow, playerCol, back);
        if (item2[2] == 3) { /* Box pulled */
            moveBox(map, boxRow, boxCol, playerRow, playerCol, 1);
            array[2] = playerRow;
            array[3] = playerCol;
        }
        result = array;
        free(item);
        free(item2);
    }
    else if (item[2] == 3) {    /* Player in range with Box */
        item2 = checkDirections(map, rows, cols, item[0], item[1], dir);
        if (item2[2] == 1 || item2[2] == 4) {   /* Box pushed */
            array[0] = item[0];
            array[1] = item[1];
            array[2] = item2[0];
            array[3] = item2[1];
            moveBox(map, boxRow, boxCol, item2[0], item2[1], 0);
            updatePositions(map, item[0], item[1], 2);
            updatePositions(map, playerRow, playerCol, 1);
        }
        result = array;
        free(item);
        free(item2);
    }
    else if (item[2] == 4) {    /* Player in range with Goal */
        updatePositions(map, playerRow, playerCol, 1);
        array[0] = item[0];
        array[1] = item[1];

        back = reversed(dir);
        item2 = checkDirections(map, rows, cols, playerRow, playerCol, back);
        if (item2[2] == 3) {
            moveBox(map, boxRow, boxCol, playerRow, playerCol, 1);
            array[2] = playerRow;
            array[3] = playerCol;
        }
        result = array;
        free(item);
        free(item2);
    }
    else {
        free(array);
    }

    return result;
}



/*Undo last  move*/

void undo(LinkedList* list, int** map, int* playerR, int* playerC, int* boxR, int* boxC){
    LLnode* node;
    Values* back; 
    node = removeNode(list, isLastState);
    if (node)
    {
        back = (Values*)node->data;
        updatePositions(map, *playerR, *playerC, 1); /* Mark prev player location as empty*/
        if (back->isBoxMoved)
        {
            updatePositions(map, *boxR, *boxC, 1);   /* Mark prev box location as empty*/
            /* new box location */
            updatePositions(map, back->boxRow, back->boxCol, 3);

            *boxR = back->boxRow;
            *boxC = back->boxCol;
        }
        updatePositions(map, back->playerRow, back->playerCol, 2); /*new playr location*/
        *playerR = back->playerRow;
        *playerC = back->playerCol;
        free(node);
        free(back);
    }

}

/*Check if box pos match with goal pos*/
int isWon(int boxX, int boxY, int goalX, int goalY){
    return (boxX == goalX && boxY == goalY);
}
