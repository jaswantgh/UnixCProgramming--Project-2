
#ifndef GAME_H
#define GAME_H

#include "linked_list.h"

char direction(); /*Read charcter from user keyboard input*/
int isWon(int boxX, int boxY, int goalX, int goalY); /*Check box pos match goal pos*/
void undo(LinkedList* list, int** map, int* playerR, int* playerC, int* boxR, int* boxC); /*Undo last move*/
int* movePlayer(int** map, int rows, int cols, int playerRow, int playerCol, int boxRow, int boxCol, char dir); /*Move play on map*/

#endif
