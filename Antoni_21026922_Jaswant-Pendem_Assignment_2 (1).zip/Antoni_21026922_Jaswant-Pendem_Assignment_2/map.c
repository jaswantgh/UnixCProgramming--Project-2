#include "color.h"
#include "map.h"
#include <stdio.h>
#include <stdlib.h>



void generateMap(int** map, int rows, int cols, int* wall, int size){
    int i, j;
    /* Configure array with default values */
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            /* Set up borders; border of the R^2 dimensional game */
            if (i == 0 || i == rows-1 || j == 0 || j == cols-1){
                map[i][j] = 0;
            } else  map[i][j] = 1;  /* Set up play space aka movable area */
        }
    }
    /* Updatin wall positions on the map */
    for (i = 0; i < size; i += 2)
    {
        updatePositions(map, wall[i], wall[i+1], 5);
    }
}

void updatePositions(int** map, int row, int col, int value){
    map[row][col] = value; /* Updatin positions (row, col) on the map with n values */
}



int checkTrail(int **map, LinkedList* list, int row, int col){
    /* Check path that box traveled through the space */
    LLnode* tmp;
    Values* val;
    int result = 0; 

    if (!(list->size < 2)) {
        tmp = list->head;
        while (tmp){
            val = (Values*)tmp->data;
            if (val->isBoxMoved)
            {
                if (val->boxRow == row && val->boxCol == col)
                {
                    result = 1; /* result=1 since for if box traveled through n position (row, col) */
                }
            }
            if (!result) /* Check box not to travel through n position before pointed to next node */
                tmp = tmp->next;
            else
                tmp = NULL;  /* Sets NULL to end the while loop as box has traveled through n position (row,col) */
        }
    }

    return result; /* Returning result --> if box has not traveled through n position (row, col) */
}



/*Function prints map*/
void printMap(int ** map, LinkedList* list, int rows, int cols, int won){
    int i,j;
    system("clear");
    printf("\n");
    for (i = 0; i < rows; i++) {

        for (j = 0; j < cols; j++) {
            if (map[i][j] == 0){
                printf("%s", BORDER);
            }
            else if (map[i][j] == 1){
                if (checkTrail(map, list, i, j)){
                    setBackground("blue");
                    printf("%s", EMPTY);
                    setBackground("reset");
                }else printf("%s", EMPTY);
            }
            else if (map[i][j] == 2){
                if (checkTrail(map, list, i, j)){
                    setBackground("blue");
                    printf("%s", PLAYER);
                    setBackground("reset");
                }else{
                    printf("%s", PLAYER);
                }
            }
            else if (map[i][j] == 3){
                setBackground("blue");
                printf("%s", BOX);
                setBackground("reset");

            }
            else if (map[i][j] == 4){

                if (won == 1){
                    setBackground("green");
                    printf("%s", BOX);
                } else if (won == 0){
                    setBackground("red");
                    printf("%s", GOAL);
                }
                else if (won == 3)
                {
                    setBackground("red");
                    printf("%s", PLAYER);
                }  
                setBackground("reset");
            }
            else if (map[i][j] == 5)
            {
                printf("%s", WALL);
            }

        }

        printf("\n");
    }
}
